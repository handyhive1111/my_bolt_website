import { Droplets, Home as HomeIcon, Sparkles, Shield, Sun, Wind, Building2, Award, ShieldCheck, Phone, Mail, MapPin, CheckCircle } from 'lucide-react';

interface HomeProps {
  onNavigate: (page: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  const services = [
    {
      icon: Droplets,
      title: 'Pressure Washing',
      description: 'High-powered cleaning for tough surfaces',
      price: 'From $300',
    },
    {
      icon: Sparkles,
      title: 'Soft Washing',
      description: 'Gentle cleaning for delicate surfaces',
      price: 'From $400',
    },
    {
      icon: HomeIcon,
      title: 'House Washing',
      description: 'Complete exterior home cleaning',
    },
    {
      icon: Shield,
      title: 'Roof Cleaning',
      description: 'Remove moss, algae, and debris',
    },
    {
      icon: Droplets,
      title: 'Gutter Cleaning',
      description: 'Prevent water damage and clogs',
      price: 'From $350',
    },
    {
      icon: Sun,
      title: 'Solar Panel Cleaning',
      description: 'Maximize energy efficiency',
      price: 'From $200',
    },
  ];

  const stats = [
    { value: '100%', label: 'Satisfaction Guarantee' },
    { value: 'Eco', label: 'Friendly Products' },
    { value: '10%', label: 'Veteran Discount' },
  ];

  const whyChooseUs = [
    'Proud veteran owned & operated',
    '10% discount for all veterans',
    'Fully insured for your peace of mind',
    '100% satisfaction guarantee',
    'Eco-friendly cleaning detergents',
    'Professional commercial-grade equipment',
    'Uniformed, trained technicians',
    'Fast response & same-week service',
    'Free quotes and consultations',
  ];

  const bayAreaCities = [
    'San Francisco', 'Oakland', 'San Jose', 'Berkeley', 'Palo Alto',
    'Fremont', 'Hayward', 'Sunnyvale', 'Mountain View', 'Castro Valley',
    'Walnut Creek', 'Dublin', 'Pleasanton', 'Livermore', 'San Mateo',
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="relative bg-gradient-to-br from-brand-yellow-400 via-brand-yellow-500 to-brand-yellow-600 text-brand-black py-32 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-72 h-72 bg-brand-black rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-brand-black rounded-full blur-3xl"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center">
            <div className="inline-flex items-center bg-brand-black text-brand-yellow-400 px-6 py-2 rounded-full font-bold text-sm mb-6 shadow-lg">
              <Award className="w-5 h-5 mr-2" />
              Proud Veteran Owned Business
            </div>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 drop-shadow-lg">
              Premium Exterior Cleaning for Your Bay Area Property
            </h1>
            <p className="text-2xl md:text-3xl mb-4 font-semibold italic">
              Where Every Home Gets Hive-Level Care
            </p>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto font-medium">
              Professional pressure washing, soft washing, and exterior cleaning services throughout the San Francisco Bay Area. Trusted by homeowners and businesses who demand excellence.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-6">
              <button
                onClick={() => onNavigate('contact')}
                className="bg-brand-black text-brand-yellow-400 px-8 py-4 rounded-lg text-lg font-bold hover:bg-gray-900 transform transition-all hover:scale-105 shadow-xl"
              >
                Get Free Quote
              </button>
              <button
                onClick={() => onNavigate('contact')}
                className="bg-white text-brand-black px-8 py-4 rounded-lg text-lg font-bold hover:bg-gray-100 transform transition-all hover:scale-105 shadow-xl"
              >
                Book a Service
              </button>
            </div>
            <a
              href="tel:5107571572"
              className="inline-flex items-center text-brand-black hover:text-gray-800 text-2xl font-bold"
            >
              <Phone className="w-6 h-6 mr-2" />
              (510) 757-1572
            </a>
          </div>
        </div>
      </section>

      <section className="py-20 bg-brand-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl md:text-5xl font-bold text-brand-yellow-400 mb-2">
                  {stat.value}
                </div>
                <div className="text-gray-300">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-brand-black mb-4">
              Our Services
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Premium exterior cleaning solutions for residential and commercial properties
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div
                  key={index}
                  className="bg-white p-8 rounded-xl shadow-lg hover:shadow-2xl transition-all transform hover:-translate-y-2 border-2 border-transparent hover:border-brand-yellow-400"
                >
                  <div className="bg-brand-yellow-400 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
                    <Icon className="w-8 h-8 text-brand-black" />
                  </div>
                  <h3 className="text-2xl font-bold text-brand-black mb-3">
                    {service.title}
                  </h3>
                  {service.price && (
                    <div className="text-brand-yellow-600 font-bold text-lg mb-2">
                      {service.price}
                    </div>
                  )}
                  <p className="text-gray-600 mb-4">{service.description}</p>
                </div>
              );
            })}
          </div>

          <div className="text-center">
            <button
              onClick={() => onNavigate('services')}
              className="bg-brand-yellow-400 text-brand-black px-8 py-4 rounded-lg text-lg font-bold hover:bg-brand-yellow-500 transform transition-all hover:scale-105 inline-flex items-center"
            >
              View All Services
              <span className="ml-2">→</span>
            </button>
          </div>
        </div>
      </section>

      <section className="py-20 bg-brand-yellow-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-2xl p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-4xl font-bold text-brand-black mb-6">
                  Why Choose Handy Hive Company?
                </h2>
                <ul className="space-y-4">
                  {whyChooseUs.map((item, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className="w-6 h-6 text-brand-yellow-600 mr-3 flex-shrink-0 mt-1" />
                      <span className="text-gray-700 text-lg">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="space-y-6">
                <div className="bg-brand-yellow-50 p-6 rounded-xl">
                  <Phone className="w-8 h-8 text-brand-black mb-3" />
                  <div className="font-semibold text-brand-black mb-1">Call Us Today</div>
                  <a href="tel:5107571572" className="text-brand-yellow-700 text-lg hover:underline">
                    (510) 757-1572
                  </a>
                  <p className="text-gray-600 text-sm mt-2">Fast response, same-day quotes</p>
                </div>
                <div className="bg-brand-yellow-50 p-6 rounded-xl">
                  <Mail className="w-8 h-8 text-brand-black mb-3" />
                  <div className="font-semibold text-brand-black mb-1">Email Us</div>
                  <a href="mailto:info@handyhiveco.com" className="text-brand-yellow-700 text-lg hover:underline break-all">
                    info@handyhiveco.com
                  </a>
                </div>
                <div className="bg-brand-yellow-50 p-6 rounded-xl">
                  <MapPin className="w-8 h-8 text-brand-black mb-3" />
                  <div className="font-semibold text-brand-black mb-1">Our Location</div>
                  <p className="text-gray-700">
                    4061 E Castro Valley Blvd<br />
                    Suite 426<br />
                    Castro Valley, CA 94552
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold text-brand-black mb-4">
              Proudly Serving the Entire Bay Area
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From San Francisco to San Jose, we bring premium exterior cleaning services to residential and commercial properties throughout the Bay Area
            </p>
          </div>
          <div className="bg-gray-50 p-8 rounded-2xl">
            <div className="flex flex-wrap justify-center gap-3 text-gray-700">
              {bayAreaCities.map((city, index) => (
                <span key={index} className="bg-white px-4 py-2 rounded-lg shadow-sm text-sm">
                  {city}
                </span>
              ))}
              <span className="bg-white px-4 py-2 rounded-lg shadow-sm text-sm font-semibold">
                + 50 more cities
              </span>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-brand-black text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <ShieldCheck className="w-16 h-16 text-brand-yellow-400 mx-auto mb-6" />
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready for a Cleaner Property?
          </h2>
          <p className="text-xl text-gray-300 mb-4">
            Get your free quote today and experience the Handy Hive difference
          </p>
          <p className="text-brand-yellow-400 font-semibold text-xl mb-8">
            Veterans receive 10% off all services
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('contact')}
              className="bg-brand-yellow-400 text-brand-black px-8 py-4 rounded-lg text-lg font-bold hover:bg-brand-yellow-500 transform transition-all hover:scale-105 shadow-xl"
            >
              Get Free Quote
            </button>
            <button
              onClick={() => onNavigate('blog')}
              className="bg-gray-800 text-white px-8 py-4 rounded-lg text-lg font-bold hover:bg-gray-700 transform transition-all hover:scale-105 shadow-xl"
            >
              Read Our Blog
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
