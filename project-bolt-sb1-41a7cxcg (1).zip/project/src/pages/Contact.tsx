import { useState } from 'react';
import { Phone, Mail, MapPin, Send, CheckCircle, Award } from 'lucide-react';

interface ContactProps {
  onNavigate: (page: string) => void;
}

export default function Contact({ onNavigate }: ContactProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    zipCode: '',
    service: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        name: '',
        phone: '',
        address: '',
        zipCode: '',
        service: '',
        message: '',
      });
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const services = [
    'Pressure Washing ($300+)',
    'Soft Washing ($400+)',
    'House Washing',
    'Roof Cleaning',
    'Gutter Cleaning ($350+)',
    'Solar Panel Cleaning ($200+)',
    'Moss Removal ($200+)',
    'Fence & Deck Cleaning',
    'Driveway / Sidewalk / Patio Cleaning',
    'Parking Lot Cleaning & Trash Removal',
    'Exterior Commercial Cleaning',
    'Critter Guard Installation',
    'Office Cleaning ($300+)',
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="bg-gradient-to-br from-brand-yellow-400 to-brand-yellow-600 text-brand-black py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Book a Service
            </h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto mb-4">
              Get your free quote today
            </p>
            <div className="inline-flex items-center bg-brand-black text-brand-yellow-400 px-6 py-2 rounded-full font-bold text-lg">
              <Award className="w-5 h-5 mr-2" />
              Veterans receive 10% off all services
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-brand-black mb-8">
                Contact Information
              </h2>

              <div className="space-y-6 mb-12">
                <div className="flex items-start">
                  <div className="bg-brand-yellow-400 p-4 rounded-lg mr-4">
                    <Phone className="w-6 h-6 text-brand-black" />
                  </div>
                  <div>
                    <h3 className="font-bold text-brand-black mb-1">Call Us Today</h3>
                    <a
                      href="tel:5107571572"
                      className="text-gray-700 hover:text-brand-yellow-600 text-lg"
                    >
                      (510) 757-1572
                    </a>
                    <p className="text-gray-600 text-sm mt-1">
                      Available Monday - Saturday, 8AM - 6PM
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-brand-yellow-400 p-4 rounded-lg mr-4">
                    <Mail className="w-6 h-6 text-brand-black" />
                  </div>
                  <div>
                    <h3 className="font-bold text-brand-black mb-1">Email Us</h3>
                    <a
                      href="mailto:info@handyhiveco.com"
                      className="text-gray-700 hover:text-brand-yellow-600 text-lg break-all"
                    >
                      info@handyhiveco.com
                    </a>
                    <p className="text-gray-600 text-sm mt-1">
                      Fast response—usually same day
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-brand-yellow-400 p-4 rounded-lg mr-4">
                    <MapPin className="w-6 h-6 text-brand-black" />
                  </div>
                  <div>
                    <h3 className="font-bold text-brand-black mb-1">Our Location</h3>
                    <p className="text-gray-700 text-lg">
                      4061 E Castro Valley Blvd<br />
                      Suite 426<br />
                      Castro Valley, CA 94552
                    </p>
                    <p className="text-gray-600 text-sm mt-1">
                      Serving the entire Bay Area
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-brand-yellow-50 border-2 border-brand-yellow-400 rounded-2xl p-8">
                <h3 className="text-2xl font-bold text-brand-black mb-4">
                  Why Choose Handy Hive Company?
                </h3>
                <ul className="space-y-3">
                  {[
                    'Proud veteran owned & operated',
                    '10% discount for all veterans',
                    'Fully insured for your peace of mind',
                    '100% satisfaction guarantee',
                    'Eco-friendly cleaning products',
                    'Professional commercial-grade equipment',
                    'Same-week service available',
                    'Free quotes and consultations',
                  ].map((item, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-brand-yellow-600 mr-3 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div>
              <div className="bg-gray-50 rounded-2xl p-8 shadow-lg">
                <h2 className="text-3xl font-bold text-brand-black mb-2">
                  Request Your Free Quote
                </h2>
                <p className="text-gray-600 mb-6">
                  Fast response — usually within the same day
                </p>

                {submitted ? (
                  <div className="bg-green-50 border-2 border-green-400 rounded-xl p-8 text-center">
                    <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
                    <h3 className="text-2xl font-bold text-brand-black mb-2">
                      Quote Request Received!
                    </h3>
                    <p className="text-gray-700">
                      Thank you! We'll send your free quote within the same day.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-semibold text-brand-black mb-2">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-brand-yellow-400 focus:outline-none transition-colors"
                        placeholder="John Doe"
                      />
                    </div>

                    <div>
                      <label htmlFor="phone" className="block text-sm font-semibold text-brand-black mb-2">
                        Phone *
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        required
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-brand-yellow-400 focus:outline-none transition-colors"
                        placeholder="(510) 555-1234"
                      />
                    </div>

                    <div>
                      <label htmlFor="address" className="block text-sm font-semibold text-brand-black mb-2">
                        Address *
                      </label>
                      <input
                        type="text"
                        id="address"
                        name="address"
                        required
                        value={formData.address}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-brand-yellow-400 focus:outline-none transition-colors"
                        placeholder="123 Main Street, City"
                      />
                    </div>

                    <div>
                      <label htmlFor="zipCode" className="block text-sm font-semibold text-brand-black mb-2">
                        Zip Code *
                      </label>
                      <input
                        type="text"
                        id="zipCode"
                        name="zipCode"
                        required
                        value={formData.zipCode}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-brand-yellow-400 focus:outline-none transition-colors"
                        placeholder="94552"
                      />
                    </div>

                    <div>
                      <label htmlFor="service" className="block text-sm font-semibold text-brand-black mb-2">
                        Choose a Service *
                      </label>
                      <select
                        id="service"
                        name="service"
                        required
                        value={formData.service}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-brand-yellow-400 focus:outline-none transition-colors"
                      >
                        <option value="">Select a service...</option>
                        {services.map((service, index) => (
                          <option key={index} value={service}>
                            {service}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label htmlFor="message" className="block text-sm font-semibold text-brand-black mb-2">
                        Additional Details (Optional)
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        rows={4}
                        className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-brand-yellow-400 focus:outline-none transition-colors resize-none"
                        placeholder="Tell us about your property or any special requirements..."
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-brand-yellow-400 text-brand-black px-8 py-4 rounded-lg text-lg font-bold hover:bg-brand-yellow-500 transform transition-all hover:scale-105 flex items-center justify-center"
                    >
                      <Send className="w-5 h-5 mr-2" />
                      Get Free Quote
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-brand-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Serving the Entire Bay Area</h2>
            <p className="text-xl text-gray-300">
              Professional exterior cleaning throughout San Francisco Bay Area
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 text-center">
            {[
              'San Francisco', 'Oakland', 'San Jose', 'Berkeley', 'Palo Alto',
              'Fremont', 'Hayward', 'Sunnyvale', 'Santa Clara', 'Mountain View',
              'Alameda', 'Albany', 'Castro Valley', 'Atherton', 'Belmont',
              'Benicia', 'Burlingame', 'Campbell', 'Concord', 'Cupertino',
              'Daly City', 'Danville', 'Dublin', 'Emeryville', 'Foster City',
              'Half Moon Bay', 'Lafayette', 'Livermore', 'Los Altos', 'Los Gatos',
              'Martinez', 'Menlo Park', 'Mill Valley', 'Millbrae', 'Milpitas',
              'Morgan Hill', 'Newark', 'Orinda', 'Pacifica', 'Piedmont',
              'Pleasanton', 'Redwood City', 'San Bruno', 'San Carlos', 'San Leandro',
              'San Mateo', 'San Rafael', 'San Ramon', 'Sausalito', 'Walnut Creek',
            ].map((city, index) => (
              <div
                key={index}
                className="bg-gray-900 p-3 rounded-lg border border-brand-yellow-400"
              >
                <span className="text-brand-yellow-400 font-semibold text-sm">{city}</span>
              </div>
            ))}
          </div>
          <p className="text-center text-gray-400 mt-8">
            Plus many more Bay Area communities
          </p>
        </div>
      </section>
    </div>
  );
}
