interface ServicesProps {
  onNavigate: (page: string) => void;
}

export default function Services({ onNavigate }: ServicesProps) {
  const services = [
    {
      title: 'Pressure Washing',
      description: 'High-powered cleaning removes years of dirt, grime, and stains from driveways, sidewalks, and concrete surfaces. Our commercial-grade equipment delivers professional results that transform your property.',
      price: 'Starting at $300',
      image: 'https://images.pexels.com/photos/6419129/pexels-photo-6419129.jpeg',
    },
    {
      title: 'Soft Washing',
      description: 'Gentle, low-pressure cleaning perfect for delicate surfaces like siding, roofs, and painted areas. Our eco-friendly solutions kill mold and algae at the root for longer-lasting results without damage.',
      price: 'Starting at $400',
      image: 'https://images.pexels.com/photos/48889/cleaning-washing-cleanup-the-ilo-48889.jpeg',
    },
    {
      title: 'House Washing',
      description: 'Complete exterior home cleaning that restores curb appeal and protects your investment. We safely clean all siding types, windows, trim, and architectural features to make your home look brand new.',
      price: null,
      image: 'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg',
    },
    {
      title: 'Roof Cleaning',
      description: 'Professional removal of moss, algae, and black streaks that damage shingles and reduce your roof lifespan. Our gentle methods protect your warranty while extending the life of your roof.',
      price: null,
      image: 'https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg',
    },
    {
      title: 'Gutter Cleaning',
      description: 'Protect your home from water damage with thorough gutter and downspout cleaning. We remove all debris, flush downspouts, and inspect for issues to keep water flowing away from your foundation.',
      price: 'Starting at $350',
      image: 'https://images.pexels.com/photos/8293700/pexels-photo-8293700.jpeg',
    },
    {
      title: 'Solar Panel Cleaning',
      description: 'Maximize your solar investment with professional panel cleaning. Remove dust, pollen, and bird droppings that reduce efficiency by up to 25%. Our warranty-safe methods use deionized water for streak-free results.',
      price: 'Starting at $200',
      image: 'https://images.pexels.com/photos/159397/solar-panel-array-power-sun-electricity-159397.jpeg',
    },
    {
      title: 'Moss Removal',
      description: 'Safe, effective removal of moss from roofs, walkways, patios, and driveways. We treat the area to prevent regrowth and protect your surfaces from moss damage and slippery conditions.',
      price: 'Starting at $200',
      image: 'https://images.pexels.com/photos/1268101/pexels-photo-1268101.jpeg',
    },
    {
      title: 'Fence & Deck Cleaning',
      description: 'Restore the natural beauty of your outdoor living spaces. We safely remove dirt, mildew, and weathering from wood and composite materials, preparing surfaces for staining or sealing.',
      price: null,
      image: 'https://images.pexels.com/photos/1029892/pexels-photo-1029892.jpeg',
    },
    {
      title: 'Driveway / Sidewalk / Patio Cleaning',
      description: 'Remove oil stains, tire marks, gum, and years of buildup from concrete and paver surfaces. Make your outdoor spaces look new again and improve safety by eliminating slippery algae.',
      price: null,
      image: 'https://images.pexels.com/photos/2251247/pexels-photo-2251247.jpeg',
    },
    {
      title: 'Parking Lot Cleaning & Trash Removal',
      description: 'Professional commercial services that maintain a clean, welcoming appearance for your business. Regular pressure washing and debris removal keep customers impressed and properties safe.',
      price: null,
      image: 'https://images.pexels.com/photos/753876/pexels-photo-753876.jpeg',
    },
    {
      title: 'Exterior Commercial Cleaning',
      description: 'Comprehensive cleaning for commercial buildings, storefronts, and business properties. We work on your schedule to minimize disruption while maintaining a professional appearance that attracts customers.',
      price: null,
      image: 'https://images.pexels.com/photos/2467506/pexels-photo-2467506.jpeg',
    },
    {
      title: 'Critter Guard Installation',
      description: 'Protect your gutters and roofline from pest infestations. Professional installation of durable critter guards prevents birds, squirrels, and rodents from nesting while keeping gutters flowing freely.',
      price: null,
      image: 'https://images.pexels.com/photos/1029624/pexels-photo-1029624.jpeg',
    },
    {
      title: 'Office Cleaning',
      description: 'Maintain a professional, welcoming environment for employees and clients. Our thorough interior cleaning services cover floors, windows, restrooms, and common areas with flexible scheduling options.',
      price: 'Starting at $300',
      image: 'https://images.pexels.com/photos/4098778/pexels-photo-4098778.jpeg',
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="bg-gradient-to-br from-brand-yellow-400 to-brand-yellow-600 text-brand-black py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold mb-6">
              Our Services
            </h1>
            <p className="text-xl md:text-2xl max-w-3xl mx-auto">
              Handy Hive Company provides comprehensive exterior cleaning services throughout the Bay Area. From residential homes to commercial properties, we deliver premium results with eco-friendly products and professional-grade equipment.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all transform hover:-translate-y-2"
              >
                <div className="h-48 overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold text-brand-black mb-2">
                    {service.title}
                  </h3>
                  {service.price && (
                    <div className="text-brand-yellow-600 font-bold text-lg mb-3">
                      {service.price}
                    </div>
                  )}
                  <p className="text-gray-600 mb-4 leading-relaxed">
                    {service.description}
                  </p>
                  <button
                    onClick={() => onNavigate('contact')}
                    className="w-full bg-brand-yellow-400 text-brand-black px-6 py-3 rounded-lg font-semibold hover:bg-brand-yellow-500 transition-colors"
                  >
                    Book a Service
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-brand-black text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready for a Cleaner, Brighter Property?
          </h2>
          <p className="text-xl text-gray-300 mb-4">
            Book your service today and experience the Handy Hive difference
          </p>
          <p className="text-brand-yellow-400 font-semibold text-xl mb-8">
            Veterans receive 10% off all services
          </p>
          <button
            onClick={() => onNavigate('contact')}
            className="bg-brand-yellow-400 text-brand-black px-8 py-4 rounded-lg text-lg font-bold hover:bg-brand-yellow-500 transform transition-all hover:scale-105 shadow-xl"
          >
            Get Free Quote
          </button>
        </div>
      </section>
    </div>
  );
}
