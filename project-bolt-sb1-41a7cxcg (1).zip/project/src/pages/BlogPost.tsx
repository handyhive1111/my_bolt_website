import { useState, useEffect } from 'react';
import { supabase, BlogPost as BlogPostType } from '../lib/supabase';
import { Calendar, ArrowLeft } from 'lucide-react';

interface BlogPostProps {
  slug: string;
  onNavigate: (page: string) => void;
}

export default function BlogPost({ slug, onNavigate }: BlogPostProps) {
  const [post, setPost] = useState<BlogPostType | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPost();
  }, [slug]);

  const fetchPost = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('slug', slug)
        .maybeSingle();

      if (error) throw error;
      setPost(data);
    } catch (error) {
      console.error('Error fetching post:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-brand-yellow-400 border-t-transparent"></div>
          <p className="mt-4 text-gray-600">Loading post...</p>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-brand-black mb-4">Post Not Found</h1>
            <p className="text-xl text-gray-600 mb-8">
              The blog post you're looking for doesn't exist.
            </p>
            <button
              onClick={() => onNavigate('blog')}
              className="bg-brand-yellow-400 text-brand-black px-6 py-3 rounded-lg font-semibold hover:bg-brand-yellow-500 inline-flex items-center"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Blog
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <article>
        <div className="bg-gradient-to-br from-brand-yellow-400 to-brand-yellow-600 py-12">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <button
              onClick={() => onNavigate('blog')}
              className="inline-flex items-center text-brand-black hover:text-brand-black-800 mb-6 font-semibold"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Back to Blog
            </button>
            <h1 className="text-4xl md:text-5xl font-bold text-brand-black mb-6">
              {post.title}
            </h1>
            <div className="flex items-center gap-6 text-brand-black">
              <div className="flex items-center">
                <Calendar className="w-5 h-5 mr-2" />
                <span>{formatDate(post.created_at)}</span>
              </div>
            </div>
          </div>
        </div>

        {post.image_url && (
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src={post.image_url}
                alt={post.title}
                className="w-full h-96 object-cover"
              />
            </div>
          </div>
        )}

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="prose prose-lg max-w-none">
            <p className="text-xl text-gray-700 font-medium mb-8 leading-relaxed">
              {post.excerpt}
            </p>
            <div className="text-gray-700 leading-relaxed whitespace-pre-line">
              {post.content}
            </div>
          </div>

          <div className="mt-12 pt-8 border-t-2 border-gray-200">
            <div className="bg-brand-yellow-50 border-2 border-brand-yellow-400 rounded-2xl p-8">
              <h3 className="text-2xl font-bold text-brand-black mb-4">
                Need Help With Your Project?
              </h3>
              <p className="text-gray-700 mb-6">
                Our team of experienced professionals is ready to help you with all your home improvement needs. Contact us today for a free consultation and estimate.
              </p>
              <button
                onClick={() => onNavigate('contact')}
                className="bg-brand-yellow-400 text-brand-black px-8 py-4 rounded-lg text-lg font-bold hover:bg-brand-yellow-500 transform transition-all hover:scale-105"
              >
                Contact Us Now
              </button>
            </div>
          </div>
        </div>
      </article>

      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-brand-black mb-6">
            Want to Read More?
          </h2>
          <button
            onClick={() => onNavigate('blog')}
            className="bg-brand-black text-brand-yellow-400 px-8 py-4 rounded-lg text-lg font-bold hover:bg-brand-black-800 transform transition-all hover:scale-105"
          >
            View All Blog Posts
          </button>
        </div>
      </section>
    </div>
  );
}
