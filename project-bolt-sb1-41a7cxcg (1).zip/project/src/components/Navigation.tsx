import { useState } from 'react';
import { Menu, X, Phone } from 'lucide-react';

interface NavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export default function Navigation({ currentPage, onNavigate }: NavigationProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleNavigation = (page: string) => {
    onNavigate(page);
    setIsMenuOpen(false);
  };

  return (
    <nav className="bg-brand-black text-white sticky top-0 z-50 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div
            className="flex items-center cursor-pointer group"
            onClick={() => handleNavigation('home')}
          >
            <div className="bg-brand-yellow-400 text-brand-black px-4 py-2 rounded-lg font-bold text-xl transform transition-transform group-hover:scale-105">
              Handy Hive Company
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => handleNavigation('home')}
              className={`transition-colors hover:text-brand-yellow-400 ${
                currentPage === 'home' ? 'text-brand-yellow-400 font-semibold' : ''
              }`}
            >
              Home
            </button>

            <button
              onClick={() => handleNavigation('services')}
              className={`transition-colors hover:text-brand-yellow-400 ${
                currentPage === 'services' ? 'text-brand-yellow-400 font-semibold' : ''
              }`}
            >
              Services
            </button>

            <button
              onClick={() => handleNavigation('blog')}
              className={`transition-colors hover:text-brand-yellow-400 ${
                currentPage === 'blog' ? 'text-brand-yellow-400 font-semibold' : ''
              }`}
            >
              Blog
            </button>

            <a
              href="tel:5107571572"
              className="flex items-center text-brand-yellow-400 hover:text-brand-yellow-300 font-semibold"
            >
              <Phone className="w-4 h-4 mr-2" />
              (510) 757-1572
            </a>

            <button
              onClick={() => handleNavigation('contact')}
              className="bg-brand-yellow-400 text-brand-black px-6 py-2 rounded-lg font-semibold hover:bg-brand-yellow-500 transform transition-all hover:scale-105"
            >
              Get Quote
            </button>
          </div>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 hover:bg-gray-800 rounded-lg transition-colors"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden bg-gray-900 border-t border-gray-700">
          <div className="px-4 py-4 space-y-3">
            <button
              onClick={() => handleNavigation('home')}
              className={`block w-full text-left py-2 transition-colors ${
                currentPage === 'home' ? 'text-brand-yellow-400 font-semibold' : 'hover:text-brand-yellow-400'
              }`}
            >
              Home
            </button>

            <button
              onClick={() => handleNavigation('services')}
              className={`block w-full text-left py-2 transition-colors ${
                currentPage === 'services' ? 'text-brand-yellow-400 font-semibold' : 'hover:text-brand-yellow-400'
              }`}
            >
              Services
            </button>

            <button
              onClick={() => handleNavigation('blog')}
              className={`block w-full text-left py-2 transition-colors ${
                currentPage === 'blog' ? 'text-brand-yellow-400 font-semibold' : 'hover:text-brand-yellow-400'
              }`}
            >
              Blog
            </button>

            <a
              href="tel:5107571572"
              className="block w-full text-left py-2 text-brand-yellow-400 hover:text-brand-yellow-300 font-semibold"
            >
              <Phone className="w-4 h-4 inline mr-2" />
              (510) 757-1572
            </a>

            <button
              onClick={() => handleNavigation('contact')}
              className="w-full bg-brand-yellow-400 text-brand-black px-6 py-3 rounded-lg font-semibold hover:bg-brand-yellow-500 transition-colors"
            >
              Get Quote
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
